package com.mycompany.bluetooth24042024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
