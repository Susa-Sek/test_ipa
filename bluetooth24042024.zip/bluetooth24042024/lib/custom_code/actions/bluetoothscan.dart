// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';

Future bluetoothscan() async {
  // Add your function code here!
  final flutterReactiveBle = FlutterReactiveBle();

  flutterReactiveBle.scanForDevices(withServices: []).listen((device) {
    print('Device found: ${device.name} ${device.id}');
  }, onError: (error) {
    print('Error: $error');
  });
}
